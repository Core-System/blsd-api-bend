package com.blessed.blsd_api_bend.model.entity;

import com.blessed.blsd_api_bend.model.enums.LocalConsulta;
import com.blessed.blsd_api_bend.model.enums.Pagamentos;
import com.blessed.blsd_api_bend.model.enums.StatusConsulta;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Consulta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "data_hora_inicio")
    private LocalDateTime dataHoraInicio;

    @Column(name = "data_hora_fim")
    private LocalDateTime dataHoraFim;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_pagamento")
    private Pagamentos tipoPagamento;

    @Column(name = "data_pagamento")
    private LocalDate dataPagamento;

    @Enumerated(EnumType.STRING)
    @Column(name = "local_consulta")
    private LocalConsulta localConsulta;

    @ManyToOne
    @JoinColumn(name = "fk_cliente")
    private Cliente cliente;


    @ManyToMany
    @JoinTable(
            name = "consulta_servico",
            joinColumns = @JoinColumn(name = "consulta_id"),
            inverseJoinColumns = @JoinColumn(name = "servico_id")
    )
    @JsonIgnore
    private List<Servico> servicos;

    @OneToOne
    @JoinColumn(name = "avaliacao_id")
    private Avaliacao avaliacao;

    private StatusConsulta statusConsulta;

}
